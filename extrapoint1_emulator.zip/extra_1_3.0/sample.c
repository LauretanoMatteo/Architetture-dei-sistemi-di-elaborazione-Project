/****************************************Copyright (c)****************************************************
**                                      
**                                 http://www.powermcu.com
**
**--------------File Info---------------------------------------------------------------------------------
** File name:               main.c
** Descriptions:            The GLCD application function
**
**--------------------------------------------------------------------------------------------------------
** Created by:              AVRman
** Created date:            2010-11-7
** Version:                 v1.0
** Descriptions:            The original version
**
**--------------------------------------------------------------------------------------------------------
** Modified by:             Lauretano Matteo
** Modified date:           02/01/2024
** Version:                 v2.0
** Descriptions:            file.c for initialization of different structure and peripherals
**
*********************************************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "functions.h"

#define SIMULATOR 1

#ifdef SIMULATOR
extern uint8_t ScaleFlag; // <- ScaleFlag needs to be visible for the emulator to find the symbol (can be placed also inside system_LPC17xx.h but since it is RO, it needs more work)
#endif

extern Player P1;
extern Player P2;
extern Board B;
extern uint32_t moves[100];


int main(void)
{
	
    uint16_t i = 0;
    uint16_t j = 0;

    B.X = 3;
    B.Y = 3;
    B.vertical = V;

    SystemInit(); 
    BUTTON_init();
    LCD_Initialization();
    joystick_init();

    NVIC_DisableIRQ(EINT2_IRQn);
    NVIC_DisableIRQ(EINT1_IRQn);

    init_timer(0,0x17D7840);//mette un secondo 25MHZ * 1s = 0x17D7840 0x1312D0

    init_RIT(0x004C4B40);
    enable_RIT();

    LCD_Clear(White);
		GUI_Text(54, 110, (uint8_t *)"QUORIDOR s329355", Black, White);
		GUI_Text(74, 150, (uint8_t *)"WAITING MODE", Black, White);
    GUI_Text(4, 190, (uint8_t *)" Press INT0 to start a match ", Black, White);

    for (i = 0; i < DIM; i++)
        for (j = 0; j < DIM; j++)
        {
					if(i%2!=0 && j%2!=0)
            B.matrix[i][j] = CENTER;
					else
						B.matrix[i][j] = 0;
        }

    for (i = 0; i < 100; i++)
        moves[i] = 0;

    while (1)
    {
        __ASM("wfi");
    }
		
}

/*********************************************************************************************************
      END FILE
*********************************************************************************************************/
