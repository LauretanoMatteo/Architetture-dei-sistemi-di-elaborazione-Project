#include "functions.h"

extern int count;
volatile Player P1 = {White, 3, 6, N_WALL};
volatile Player P2 = {Red, 3, 0, N_WALL};

volatile Board B;

volatile uint32_t moves[100];
volatile uint16_t joystick=0;

volatile uint16_t mode=P_MODE;

volatile uint16_t turn = P1_TURN;

/******************************************************************************
** Function name:		recursive_check_trap
**
** Descriptions:		check if the players are trapped by the walls
**
** parameters:			uint16_t  x, uint16_t  y, uint16_t endY, uint16_t board [DIM][DIM]
** Returned value:		int value
**
******************************************************************************/

static int recursive_check_trap(uint16_t  x, uint16_t  y, uint16_t endY, uint16_t board [DIM][DIM]){
	
		if (y == endY) 
			return 1; 
		if (board[y][x]==CHECKED || board[y][x]==WALL || board[y][x]==H_CENTER || board[y][x]==V_CENTER || board[y][x]==CENTER) 
			return 0;
    
		board[y][x] = CHECKED;
	
		if (x > 0) 
        if (recursive_check_trap(x-1, y, endY, board)) { // Recalls method one to the left
            return 1;
        }
    if (x < 12) // Checks if not on right edge
        if (recursive_check_trap(x+1, y, endY, board)) { // Recalls method one to the right
            return 1;
        }
    if (y > 0)  // Checks if not on top edge
        if (recursive_check_trap(x, y-1, endY, board)) { // Recalls method one up
            return 1;
        }
    if (y < 12) // Checks if not on bottom edge
        if (recursive_check_trap(x, y+1, endY, board)) { // Recalls method one down
            return 1;
        }
    return 0;
} 

/******************************************************************************
** Function name:		draw_square
**
** Descriptions:		draw a square on the display with the specified offset
**
** parameters:			int lato_corto, int lato_lungo, int padding, int offsetx, int offsety, int valore_offsetx, int valore_offsety, uint16_t color
** Returned value:	None
**
******************************************************************************/

void draw_square(int lato_corto, int lato_lungo, int padding, int offsetx, int offsety, int valore_offsetx, int valore_offsety, uint16_t color){
	
	offsetx=offsetx*valore_offsetx;
	offsety=offsety*valore_offsety;
	
	LCD_DrawLine(padding+offsetx, padding+offsety, padding+offsetx, lato_corto+offsety, color);
	LCD_DrawLine(padding+offsetx, lato_corto+offsety, lato_lungo+offsetx, lato_corto+offsety, color);
	LCD_DrawLine(lato_lungo+offsetx, lato_corto+offsety, lato_lungo+offsetx, padding+offsety, color);
	LCD_DrawLine(lato_lungo+offsetx, padding+offsety, padding+offsetx, padding+offsety, color);
	
}

/******************************************************************************
** Function name:		highlight_move
**
** Descriptions:		highlights the possible moves for the specified player, with respect of the walls
**
** parameters:			uint16_t  turn, uint16_t color
** Returned value:	None
**
******************************************************************************/

void highlight_move (uint16_t  turn, uint16_t color){
	
	uint16_t x_matrix;
	uint16_t y_matrix;
	
	if(turn==P1_TURN){
		
		x_matrix=2*P1.X;
		y_matrix=2*P1.Y;
		
		if(P1.Y != 0 && B.matrix[y_matrix-1][x_matrix]!=WALL && (P1.Y-1!=P2.Y || P1.X!=P2.X))
			draw_square(LATO-3, LATO-3, PADDING+3, P1.X,P1.Y-1, 33, 33, color);			//sopra
		if(P1.X != 6 && B.matrix[y_matrix][x_matrix+1]!=WALL && (P1.Y!=P2.Y || P1.X+1!=P2.X))
			draw_square(LATO-3, LATO-3, PADDING+3, P1.X+1,P1.Y, 33, 33, color);		  //destra
		if(P1.X != 0 && B.matrix[y_matrix][x_matrix-1]!=WALL && (P1.Y!=P2.Y || P1.X-1!=P2.X))
			draw_square(LATO-3, LATO-3, PADDING+3, P1.X-1,P1.Y, 33, 33, color);			//sinistra
		if(P1.Y != 6 && B.matrix[y_matrix+1][x_matrix]!=WALL && (P1.Y+1!=P2.Y || P1.X!=P2.X))
			draw_square(LATO-3, LATO-3, PADDING+3, P1.X,P1.Y+1, 33, 33, color);			//sotto
		
		if(P1.Y-1==P2.Y && P1.X==P2.X && B.matrix[y_matrix-1][x_matrix]!=WALL)
			if(P1.Y>1)
				if(B.matrix[y_matrix-3][x_matrix]!=WALL)
					draw_square(LATO-3, LATO-3, PADDING+3, P1.X,P1.Y-2, 33, 33, color);
		
		if(B.matrix[y_matrix][x_matrix+1]!=WALL && P1.Y==P2.Y && P1.X+1==P2.X)
			if(P1.X<5)
				if(B.matrix[y_matrix][x_matrix+3]!=WALL)
					draw_square(LATO-3, LATO-3, PADDING+3, P1.X+2,P1.Y, 33, 33, color);
			
		if(B.matrix[y_matrix][x_matrix-1]!=WALL && P1.Y==P2.Y && P1.X-1==P2.X)
			if(P1.X>1)
				if(B.matrix[y_matrix][x_matrix-3]!=WALL)
					draw_square(LATO-3, LATO-3, PADDING+3, P1.X-2,P1.Y, 33, 33, color);
			
		if(B.matrix[y_matrix+1][x_matrix]!=WALL && P1.Y+1==P2.Y && P1.X==P2.X)
			if(P1.Y<5)
				if(B.matrix[y_matrix+3][x_matrix]!=WALL)
					draw_square(LATO-3, LATO-3, PADDING+3, P1.X,P1.Y+2, 33, 33, color);
			
	}else{
		
		x_matrix=2*P2.X;
		y_matrix=2*P2.Y;
		
		if(P2.Y != 0 && B.matrix[y_matrix-1][x_matrix]!=WALL && (P1.Y!=P2.Y-1 || P1.X!=P2.X))
			draw_square(LATO-3, LATO-3, PADDING+3, P2.X,P2.Y-1, 33, 33, color);			//sopra
		if(P2.X != 6 && B.matrix[y_matrix][x_matrix+1]!=WALL && (P1.Y!=P2.Y || P1.X!=P2.X+1))
			draw_square(LATO-3, LATO-3, PADDING+3, P2.X+1,P2.Y, 33, 33, color);		  //destra
		if(P2.X != 0 && B.matrix[y_matrix][x_matrix-1]!=WALL && (P1.Y!=P2.Y || P1.X!=P2.X-1))
			draw_square(LATO-3, LATO-3, PADDING+3, P2.X-1,P2.Y, 33, 33, color);			//sinistra
		if(P2.Y != 6 && B.matrix[y_matrix+1][x_matrix]!=WALL && (P1.Y!=P2.Y+1 || P1.X!=P2.X))
			draw_square(LATO-3, LATO-3, PADDING+3, P2.X,P2.Y+1, 33, 33, color);			//sotto
		
		if(P2.Y-1==P1.Y && P1.X==P2.X && B.matrix[y_matrix-1][x_matrix]!=WALL)
			if(P2.Y>1)
				if(B.matrix[y_matrix-3][x_matrix]!=WALL)
					draw_square(LATO-3, LATO-3, PADDING+3, P2.X,P2.Y-2, 33, 33, color);
		
		if(B.matrix[y_matrix][x_matrix+1]!=WALL && P2.Y==P1.Y && P2.X+1==P1.X)
			if(P2.X<5)
				if(B.matrix[y_matrix][x_matrix+3]!=WALL)
					draw_square(LATO-3, LATO-3, PADDING+3, P2.X+2,P2.Y, 33, 33, color);
			
		if(B.matrix[y_matrix][x_matrix-1]!=WALL && P1.Y==P2.Y && P2.X-1==P1.X)
			if(P2.X>1)
				if(B.matrix[y_matrix][x_matrix-3]!=WALL)
					draw_square(LATO-3, LATO-3, PADDING+3, P2.X-2,P2.Y, 33, 33, color);
			
		if(B.matrix[y_matrix+1][x_matrix]!=WALL && P2.Y+1==P1.Y && P1.X==P2.X)
			if(P2.Y<5)
				if(B.matrix[y_matrix+3][x_matrix]!=WALL)
					draw_square(LATO-3, LATO-3, PADDING+3, P2.X,P2.Y+2, 33, 33, color);
	}
}

/******************************************************************************
** Function name:		make_move
**
** Descriptions:		make the move chosed by the player
**
** parameters:			uint16_t  turn, uint16_t direction
** Returned value:	int value
**
******************************************************************************/

int make_move(uint16_t turn, uint16_t  direction){
	
	uint16_t x_matrix;
	uint16_t y_matrix;
	
	highlight_move(turn, Black);
	if(turn==P1_TURN){
			x_matrix=2*P1.X;
			y_matrix=2*P1.Y;
		  draw_square(LATO-3, LATO-3, PADDING+3, P1.X,P1.Y, 33, 33, Black);
			switch (direction){
					case DOWN:	
					  if(P1.Y<6 && B.matrix[y_matrix+1][x_matrix]!=WALL){
							if(P1.Y+1!=P2.Y || P1.X!=P2.X)
								P1.Y++;
							else if(P1.Y<5){
								if(B.matrix[y_matrix+3][x_matrix]!=WALL)
									P1.Y=P1.Y+2;
							}else
								return 0;
						}else
							return 0;
					break;
					case LEFT:
						if(P1.X>0 && B.matrix[y_matrix][x_matrix-1]!=WALL){
							if(P1.Y!=P2.Y || P1.X-1!=P2.X)
								P1.X--;
							else if(P1.X>1){
								if(B.matrix[y_matrix][x_matrix-3]!=WALL)
									P1.X=P1.X-2;
							}else
								return 0;
						}else
							return 0;
					break;
					case RIGHT:
						if(P1.X<6 && B.matrix[y_matrix][x_matrix+1]!=WALL){
							if(P1.Y!=P2.Y || P1.X+1!=P2.X)
								P1.X++;
							else if(P1.X<5){
								if(B.matrix[y_matrix][x_matrix+3]!=WALL)
									P1.X=P1.X+2;
							}else
								return 0;
						}else
							return 0;
					break;
					case UP:
						if(P1.Y>0 && B.matrix[y_matrix-1][x_matrix]!=WALL){
							if(P1.Y-1!=P2.Y || P1.X!=P2.X)
								P1.Y--;
							else if(P1.Y>1){
								if(B.matrix[y_matrix-3][x_matrix]!=WALL)
									P1.Y=P1.Y-2;
							}else
								return 0;
						}else
							return 0;
					break;
					default:
						return 0;
								
				}
			draw_square(LATO-3, LATO-3, PADDING+3, P1.X,P1.Y, 33, 33, P1.color);
	}else{
			x_matrix=2*P2.X;
			y_matrix=2*P2.Y;
			draw_square(LATO-3, LATO-3, PADDING+3, P2.X,P2.Y, 33, 33, Black);
			switch (direction){
					case DOWN:	
						if(P2.Y<6 && B.matrix[y_matrix+1][x_matrix]!=WALL){
							if(P1.Y!=P2.Y+1 || P1.X!=P2.X)
								P2.Y++;
							else if(P2.Y<5){
								if(B.matrix[y_matrix+3][x_matrix]!=WALL)
									P2.Y=P2.Y+2;
							}else
								return 0;
						}else
							return 0;
					break;
					case LEFT:
						if(P2.X>0 && B.matrix[y_matrix][x_matrix-1]!=WALL){
							if(P1.Y!=P2.Y || P1.X!=P2.X-1)
								P2.X--;
							else if(P2.X>1){
								if(B.matrix[y_matrix][x_matrix-3]!=WALL)
									P2.X=P2.X-2;
							}else
								return 0;
						}else
							return 0;
					break;
					case RIGHT:
						if(P2.X<6 && B.matrix[y_matrix][x_matrix+1]!=WALL){
							if(P1.Y!=P2.Y || P1.X!=P2.X+1)
								P2.X++;
							else if(P2.X<5){
								if(B.matrix[y_matrix][x_matrix+3]!=WALL)
									P2.X=P2.X+2;
							}else
								return 0;
						}else
							return 0;
					break;
					case UP:
						if(P2.Y>0 && B.matrix[y_matrix-1][x_matrix]!=WALL){
							if(P1.Y!=P2.Y-1 || P1.X!=P2.X)
								P2.Y--;
							else if(P2.Y>1){
								if(B.matrix[y_matrix-3][x_matrix]!=WALL)
									P2.Y=P2.Y-2;
							}else
								return 0;
						}else
							return 0;
					break;
					default:
						return 0;
									
				}
			draw_square(LATO-3, LATO-3, PADDING+3, P2.X,P2.Y, 33, 33, P2.color);
	
	}
	
	return 1;
	
}

/******************************************************************************
** Function name:		select_move
**
** Descriptions:	  highlight the move choosed by the player
**
** parameters:			uint16_t  turn, uint16_t direction
** Returned value:	None
**
******************************************************************************/

void select_move(uint16_t  turn, uint16_t direction){
	
	/*int x_matrix;
	int y_matrix;*/
	if(turn==P1_TURN){
			/*x_matrix=2*P1.X;
			y_matrix=2*P1.Y;**/
			switch (direction){
					case DOWN:	
					  if(B.matrix[P1.Y*2+1][P1.X*2]!=WALL && P1.Y!=6){
						if(P1.Y+1!=P2.Y || P1.X!=P2.X)
								draw_square(LATO-3, LATO-3, PADDING+3, P1.X,P1.Y+1, 33, 33, Blue);
							else if(B.matrix[P1.Y*2+3][P1.X*2]!=WALL){
								draw_square(LATO-3, LATO-3, PADDING+3, P1.X,P1.Y+2, 33, 33, Blue);
							}
						}
					break;
					case LEFT:
						if(B.matrix[P1.Y*2][P1.X*2-1]!=WALL && P1.X!=0){
							if(P1.Y!=P2.Y || P1.X-1!=P2.X)
								draw_square(LATO-3, LATO-3, PADDING+3, P1.X-1,P1.Y, 33, 33, Blue);
							else if(B.matrix[P1.Y*2][P1.X*2-3]!=WALL){
								draw_square(LATO-3, LATO-3, PADDING+3, P1.X-2,P1.Y, 33, 33, Blue);
							}
						}
					break;
					case RIGHT:
						if(B.matrix[P1.Y*2][P1.X*2+1]!=WALL && P1.X!=6){
							if(P1.Y!=P2.Y || P1.X+1!=P2.X)
								draw_square(LATO-3, LATO-3, PADDING+3, P1.X+1,P1.Y, 33, 33, Blue);
							else if(B.matrix[P1.Y*2+3][P1.X*2+3]!=WALL){
								draw_square(LATO-3, LATO-3, PADDING+3, P1.X+2,P1.Y, 33, 33, Blue);
							}
						}
					break;
					case UP:
					if(B.matrix[P1.Y*2-1][P1.X*2]!=WALL && P1.Y!=0){
						if(P1.Y-1!=P2.Y || P1.X!=P2.X)
								draw_square(LATO-3, LATO-3, PADDING+3, P1.X,P1.Y-1, 33, 33, Blue);
							else if(B.matrix[P1.Y*2-3][P1.X*2]!=WALL){
								draw_square(LATO-3, LATO-3, PADDING+3, P1.X,P1.Y-2, 33, 33, Blue);
							}
						}
					break;
					default:
					break;
					
				}
					
			
	}else{
		switch(direction){
					case DOWN:	
					  if(B.matrix[P2.Y*2+1][P2.X*2]!=WALL && P2.Y!=6){
						if(P1.Y!=P2.Y+1 || P1.X!=P2.X)
								draw_square(LATO-3, LATO-3, PADDING+3, P2.X,P2.Y+1, 33, 33, Blue);
							else if(B.matrix[P2.Y*2+3][P2.X*2]!=WALL){
								draw_square(LATO-3, LATO-3, PADDING+3, P2.X,P2.Y+2, 33, 33, Blue);
							}
						}
					break;
					case LEFT:
						if(B.matrix[P2.Y*2][P2.X*2-1]!=WALL && P2.X!=0){
							if(P1.Y!=P2.Y || P1.X!=P2.X-1)
								draw_square(LATO-3, LATO-3, PADDING+3, P2.X-1,P2.Y, 33, 33, Blue);
							else if(B.matrix[P1.Y*2][P1.X*2-3]!=WALL){
								draw_square(LATO-3, LATO-3, PADDING+3, P2.X-2,P2.Y, 33, 33, Blue);
							}
						}
					break;
					case RIGHT:
						if(B.matrix[P2.Y*2][P2.X*2+1]!=WALL && P2.X!=6){
							if(P1.Y!=P2.Y || P1.X!=P2.X+1)
								draw_square(LATO-3, LATO-3, PADDING+3, P2.X+1,P2.Y, 33, 33, Blue);
							else if(B.matrix[P2.Y*2][P2.X*2+3]!=WALL){
								draw_square(LATO-3, LATO-3, PADDING+3, P2.X+2,P2.Y, 33, 33, Blue);
							}
						}
					break;
					case UP:
					if(B.matrix[P2.Y*2-1][P2.X*2]!=WALL && P2.Y!=0){
						if(P1.Y!=P2.Y -1 || P1.X!=P2.X)
								draw_square(LATO-3, LATO-3, PADDING+3, P2.X,P2.Y-1, 33, 33, Blue);
							else if(B.matrix[P2.Y*2-3][P2.X*2]!=WALL){
								draw_square(LATO-3, LATO-3, PADDING+3, P2.X,P2.Y-2, 33, 33, Blue);
							}
						}
					break;
					default:
					break;
					
				}		
	}	
}

/******************************************************************************
** Function name:		draw_wall
**
** Descriptions:		draw a wall with the specified offset
**
** parameters:			int lunghezza, int padding, int offsetx, int offsety, int valore_offsetx, int valore_offsety, int vertical, uint16_t color
** Returned value:	None
**
******************************************************************************/

void draw_wall(int lunghezza, int padding, int offsetx, int offsety, int valore_offsetx, int valore_offsety, int vertical, uint16_t color){
	
	uint16_t i;
	
	offsetx=offsetx*valore_offsetx;
	offsety=offsety*valore_offsety;
	//draw_wall(70, 2, 3, 3, 33, 33, vertical, Magenta);
	if(vertical==V){
		
		for(i=0;i<3;i++){
			LCD_DrawLine(padding+offsetx+i, padding+offsety, padding+offsetx+i, lunghezza/2+offsety, color);
			LCD_DrawLine(padding+offsetx+i, padding+offsety, padding+offsetx+i, (offsety-lunghezza/2)+6, color);
		}
		
	}else{
		
		for(i=0;i<3;i++){
			LCD_DrawLine(padding+offsetx, offsety+i+2, lunghezza/2+offsetx, offsety+i+2, color);
			LCD_DrawLine(padding+offsetx, offsety+i+2, (offsetx-lunghezza/2)+6, offsety+i+2, color);
		}
		
	}
}

/******************************************************************************
** Function name:		print_warning
**
** Descriptions:		print a warning when the walls are finished
**
** parameters:			int lunghezza, int padding, int offsetx, int offsety, int valore_offsetx, int valore_offsety, int vertical, uint16_t color
** Returned value:	None
**
******************************************************************************/

void print_warning(){
	
	GUI_Text(0, 235, (uint8_t *) "   No walls available, move   ", White, Black);
	GUI_Text(0, 250, (uint8_t *) "           the token          ", White, Black);
	highlight_move(turn,Black);
	joystick=0;
	NVIC_DisableIRQ(EINT2_IRQn);
	
}

/******************************************************************************
** Function name:		redo_wall
**
** Descriptions:		reset the walls saved in the matrix
**
** parameters:			None
** Returned value:	None
**
******************************************************************************/

void redo_wall(){
	
	uint16_t x_matrix=2*B.X-1;
	uint16_t y_matrix=2*B.Y-1;
	
	draw_wall(L_WALL, 2, B.X, B.Y, 33, 33, B.vertical, Black);
	
	if(B.matrix[y_matrix][x_matrix]==V_CENTER)
		draw_wall(L_WALL, 2, B.X, B.Y, 33, 33, V, Green);
	
	if(B.matrix[y_matrix][x_matrix]==H_CENTER)
		draw_wall(L_WALL, 2, B.X, B.Y, 33, 33, H, Green);
	
	if(B.vertical==V){
		if(y_matrix<10)
			if(B.matrix[y_matrix+2][x_matrix]==V_CENTER)
				draw_wall(L_WALL, 2, B.X, B.Y+1, 33, 33, V, Green);
		if(y_matrix>2)
			if(B.matrix[y_matrix-2][x_matrix]==V_CENTER)
				draw_wall(L_WALL, 2, B.X, B.Y-1, 33, 33, V, Green);
	}
	
	if(B.vertical==H){
		if(x_matrix<10)
			if(B.matrix[y_matrix][x_matrix+2]==H_CENTER)
				draw_wall(L_WALL, 2, B.X+1, B.Y, 33, 33, H, Green);
		if(x_matrix>2)
			if(B.matrix[y_matrix][x_matrix-2]==H_CENTER)
				draw_wall(L_WALL, 2, B.X-1, B.Y, 33, 33, H, Green);
	}
	
		
}

/******************************************************************************
** Function name:		set_wall
**
** Descriptions:		saves a wall in the matrix 
**
** parameters:			uint16_t turn
** Returned value:	None
**
******************************************************************************/

int set_wall(uint16_t  turn){	
	
	uint16_t i=0;
	uint16_t j=0;
  uint16_t x_matrix=2*B.X-1;
	uint16_t y_matrix=2*B.Y-1;
  uint16_t board[DIM][DIM];
	uint16_t notrap=0;
	

	for(i=0;i<DIM;i++)
		for(j=0;j<DIM;j++){
			board[i][j]=B.matrix[i][j];
		}
	
	if(B.matrix[y_matrix][x_matrix]==V_CENTER || B.matrix[y_matrix][x_matrix]==H_CENTER)
		return 0;
	else{
		if(B.vertical==V){
			if(y_matrix>1 && y_matrix<11)
				if(B.matrix[y_matrix-2][x_matrix]==V_CENTER || B.matrix[y_matrix+2][x_matrix]==V_CENTER)
					return 0;
			board[y_matrix][x_matrix]=V_CENTER;
			board[y_matrix-1][x_matrix]=WALL;
			board[y_matrix+1][x_matrix]=WALL;
		}else{
			if(x_matrix>1 && x_matrix<11)
				if(B.matrix[y_matrix][x_matrix+2]==H_CENTER || B.matrix[y_matrix][x_matrix-2]==H_CENTER)
					return 0;
			board[y_matrix][x_matrix]=H_CENTER;
			board[y_matrix][x_matrix+1]=WALL;
			board[y_matrix][x_matrix-1]=WALL;
		}
		
		notrap=recursive_check_trap(P2.X*2,P2.Y*2,12,board);
		
		for(i=0;i<DIM;i++)
			for(j=0;j<DIM;j++){
				/*if(board[i][j]==CHECKED)
					board[i][j]=0;*/
				board[i][j]=B.matrix[i][j];
		}
		
		//so che le condizioni sono verificate, altrimenti non arriverei qui
		if(B.vertical==V){
			board[y_matrix][x_matrix]=V_CENTER;
			board[y_matrix-1][x_matrix]=WALL;
			board[y_matrix+1][x_matrix]=WALL;
		}else{
			board[y_matrix][x_matrix]=H_CENTER;
			board[y_matrix][x_matrix+1]=WALL;
			board[y_matrix][x_matrix-1]=WALL;
		}
		
		notrap=notrap&&recursive_check_trap(P1.X*2,P1.Y*2,0,board);
		
		if(!notrap){
			return 0;
		}else{
			if(B.vertical==V){
				B.matrix[y_matrix][x_matrix]=V_CENTER;
				B.matrix[y_matrix-1][x_matrix]=WALL;
				B.matrix[y_matrix+1][x_matrix]=WALL;
			}else{
				B.matrix[y_matrix][x_matrix]=H_CENTER;
				B.matrix[y_matrix][x_matrix+1]=WALL;
				B.matrix[y_matrix][x_matrix-1]=WALL;
			}
			
			draw_wall(L_WALL, 2, B.X, B.Y, 33, 33, B.vertical, Green);
			B.X=3;
			B.Y=3;
			return 1;
		}
		
	}
	
}

/******************************************************************************
** Function name:		add_move
**
** Descriptions:		adds a move in the moves' vector 
**
** parameters:			uint16_t turn, uint16_t  mode, uint16_t vertical, uint16_t  y, uint16_t  x, uint32_t* moves
** Returned value:	None
**
******************************************************************************/

void add_move(uint16_t turn, uint16_t  mode, uint16_t vertical, uint16_t  y, uint16_t  x, uint32_t* moves){
	
	static uint16_t count=0;
	uint32_t move;
	
	
	if(mode==P_MODE){
		x=PADDING+3+x*LATO;
		y=PADDING+3+y*LATO;
	}else{
		x=PADDING-3+x*LATO;
		y=PADDING-3+y*LATO;
	}
	
	move |= (turn << 24);  // PlayerID: 1
  move |= (mode << 20);  // Wall/Move: 0 (Player Move)
  move |= (vertical << 16);  // Vertical/Horizontal: 0 (Default for player move)
  move |= (y << 8);   // Y: 5
  move |= x;         // X: 10
	
	moves[count]=move;
	count++;
	
}

/******************************************************************************
** Function name:		end_game
**
** Descriptions:		print the end game screen
**
** parameters:			uint16_t turn
** Returned value:	None
**
******************************************************************************/

void end_game(uint16_t  turn){
	
	disable_timer(0);
	disable_RIT();
	NVIC_DisableIRQ(EINT0_IRQn);
	NVIC_DisableIRQ(EINT1_IRQn);
	NVIC_DisableIRQ(EINT2_IRQn);
	LCD_Clear(White);
	
	if(turn==P2_TURN){
		GUI_Text(76, 110, (uint8_t *)"GAME OVER", Black, White);
		GUI_Text(64, 150, (uint8_t *)"PLAYER 2 WINS", Black, White);
	}else{
		GUI_Text(76, 110, (uint8_t *)"GAME OVER", Black, White);
		GUI_Text(64, 150, (uint8_t *)"PLAYER 1 WINS", Black, White);
	}
	
}

/******************************************************************************
** Function name:		switch_player_wall
**
** Descriptions:		choose the correct counter for the walls 
**
** parameters:			uint16_t turn
** Returned value:	None
**
******************************************************************************/

void switch_player_wall(uint16_t turn){
	
	char stringa[5];
	
	if(turn==P2_TURN){
		P2.walls--;
		sprintf(stringa, "%d", P2.walls);
		GUI_Text(192, FINE + 30, (uint8_t *) "  ", Black, Black);
		GUI_Text(192, FINE + 30, (uint8_t *) stringa, P2.color, Black);	
	}else{
		P1.walls--;
		sprintf(stringa, "%d", P1.walls);
		GUI_Text(32, FINE + 30, (uint8_t *) "  ", Black, Black);
		GUI_Text(32, FINE + 30, (uint8_t *) stringa, P1.color, Black);					
	}
	
}


/******************************************************************************
** Function name:		reset_turn
**
** Descriptions:		reset the variables after the end of a turn 
**
** parameters:			uint16_t turn
** Returned value:	None
**
******************************************************************************/

void reset_turn(uint16_t turn){
	
	char stringa[5];
	
	B.X=3;
	B.Y=3;
	highlight_move(turn, Yellow);
	disable_timer(0);																							//fermo il timer
  reset_timer(0);                                              //resetto il timer
	count=TIME;
	sprintf(stringa, "%d", count);
	strcat(stringa,"s");
	GUI_Text(112, FINE+20, (uint8_t *) "   ", Black, Black);
	GUI_Text(112, FINE+20, (uint8_t *) stringa, White, Black);
	enable_timer(0);
	
}

/******************************************************************************
** Function name:		set_board
**
** Descriptions:		print on the displat the board 
**
** parameters:			None
** Returned value:	None
**
******************************************************************************/

void set_board(){
	
	char stringa[5];
	uint16_t i=0;
	uint16_t j=0;
	
	
	
	for(i=0;i<7;i++){
		for(j=0;j<7;j++){
			draw_square(LATO, LATO, PADDING, j,i, LATO,LATO, White);
		}
	}
	
	for(i=0;i<3;i++)
		draw_square(LATO_CORTO, LATO_LUNGO, PADDING, i, 1, 80, FINE, White);    //fine usato per mettere i rettangoli in fondo al display
	
	
	GUI_Text(12, FINE + 10, (uint8_t *) "P1 Wall", P1.color, Black);
	GUI_Text(172, FINE + 10, (uint8_t *) "P2 Wall", P2.color, Black);
	
	sprintf(stringa, "%d", P1.walls);
	GUI_Text(32, FINE + 30, (uint8_t *) stringa, P1.color, Black);
	
	sprintf(stringa, "%d", P2.walls);
	GUI_Text(192, FINE + 30, (uint8_t *) stringa, P2.color, Black);
	
	sprintf(stringa, "%d", count);
	strcat(stringa,"s");
	GUI_Text(112, FINE + 20, (uint8_t *) stringa, White, Black);
	
	draw_square(LATO-3, LATO-3, PADDING+3, P1.X,P1.Y, LATO, LATO, P1.color);			//pedine
	draw_square(LATO-3, LATO-3, PADDING+3, P2.X,P2.Y, LATO, LATO, P2.color);
	
}

/******************************************************************************
** Function name:		rotate_wall
**
** Descriptions:		rotate a wall of 90� respect to the position
**
** parameters:			None
** Returned value:	None
**
******************************************************************************/

void rotate_wall(){
	
	if (B.vertical==V){
		draw_wall(L_WALL, 2, B.X, B.Y, 33, 33, B.vertical, Black);
		redo_wall();
		B.vertical=H;
		draw_wall(L_WALL, 2, B.X, B.Y, 33, 33, B.vertical, Magenta);	
	}else{
		draw_wall(L_WALL, 2, B.X, B.Y, 33, 33, B.vertical, Black);
		redo_wall();
		B.vertical=V;
		draw_wall(L_WALL, 2, B.X, B.Y, 33, 33, B.vertical, Magenta);
	}
	
}

