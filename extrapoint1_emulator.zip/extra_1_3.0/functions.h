/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           functions.h
** Created by:          Lauretano Matteo
** Created date:        2020-01-02
** Version:             v1.0
** Descriptions:        atomic functions used by the game
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/

#include "LPC17xx.h"
#include "GLCD/GLCD.h" 
#include "timer/timer.h"
#include "button_EXINT/button.h"
#include "joystick/joystick.h"
#include "RIT/RIT.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define LATO 33
#define LATO_CORTO 50
#define LATO_LUNGO 72
#define PADDING 6
#define FINE 265
#define L_WALL 70
#define DOWN 1
#define LEFT 2
#define RIGHT 3
#define UP 4
#define H_CENTER 10
#define V_CENTER 1
#define CHECKED 11
#define DIM 13
#define WALL 2
#define N_WALL 8
#define CENTER 7

#define P1_TURN 1
#define P2_TURN 2
#define W_MODE 1
#define P_MODE 0
#define V 0
#define H 1
#define TIME 20

typedef struct {
	uint16_t color;
	uint16_t X;
	uint16_t Y;
  uint16_t walls;
}Player;

typedef struct {
	uint16_t matrix[DIM][DIM];
	uint16_t X;
	uint16_t Y;
	uint16_t vertical;
}Board;


void draw_square(int lato_corto, int lato_lungo, int padding, int offsetx, int offsety, int valore_offsetx, int valore_offsety, uint16_t color);
void draw_wall(int lunghezza, int padding, int offsetx, int offsety, int valore_offsetx, int valore_offsety, int vertical, uint16_t color);
void print_warning(void);
void set_board(void);
void end_game(uint16_t  turn);

void highlight_move (uint16_t  turn,  uint16_t color);
int make_move(uint16_t  turn, uint16_t  direction);
void select_move(uint16_t turn,uint16_t direction);

void redo_wall(void);
void rotate_wall(void);
int set_wall(uint16_t  turn);
void switch_player_wall(uint16_t turn);
int static recursive_check_trap(uint16_t  x, uint16_t  y, uint16_t  endY, uint16_t board [DIM][DIM]);////

void add_move(uint16_t  turn,uint16_t mode, uint16_t  vertical, uint16_t  y, uint16_t  x, uint32_t* moves);
void reset_turn(uint16_t turn);









