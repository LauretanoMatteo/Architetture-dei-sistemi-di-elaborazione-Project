/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_RIT.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    RIT.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "../functions.h"

/******************************************************************************
** Function name:		RIT_IRQHandler
**
** Descriptions:		REPETITIVE INTERRUPT TIMER handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/

volatile int down_0 = 0;
volatile int down_1 = 0;
volatile int down_2 = 0;

volatile uint16_t direction = 0;

extern Board B;
extern Player P1;
extern Player P2;
extern uint16_t count;
extern uint16_t mode;
extern uint32_t moves[100];
extern uint16_t joystick;
extern uint16_t turn;


void RIT_IRQHandler (void)
{	
	static int J_select=0;
	static int J_down = 0;
	static int J_left =0;
	static int J_right =0;
	static int J_up =0;
	int walls;
	
	if(joystick){
	if((LPC_GPIO1->FIOPIN & (1<<25)) == 0){	
		
		J_select++;
		switch(J_select){
			case 1:
				if(mode==P_MODE){
					if(make_move(turn, direction)){
						if(turn==P2_TURN){
							add_move(turn,mode,B.vertical,P2.Y,P2.X,moves);
							if(P2.Y==6){
								end_game(turn);
								return;
							}
						}else{
							add_move(turn,mode,B.vertical,P1.Y,P1.X,moves);
							if(P1.Y==0){
								end_game(turn);
								return;
							}
						}
					}else{
						highlight_move(turn, Yellow);
						if(turn==P2_TURN){
							draw_square(LATO-3, LATO-3, PADDING+3, P2.X,P2.Y, 33, 33, P2.color);
						}else{
							draw_square(LATO-3, LATO-3, PADDING+3, P1.X,P1.Y, 33, 33, P1.color);
						}
						direction = 0;
						return;
					}
				}else{
					if(set_wall(turn)){
						add_move(turn,mode,B.vertical,B.Y,B.X,moves);
						switch_player_wall(turn);
						NVIC_DisableIRQ(EINT2_IRQn);
					  direction =0;
					}else{
						return;
					}
				}
				
				mode=P_MODE;
				if(turn==P2_TURN)
					turn=P1_TURN;
				else
					turn=P2_TURN;
				reset_turn(turn);
				NVIC_DisableIRQ(EINT2_IRQn);
				
				break;
			default:
				break;
		}
		direction = 0;
	}
	else{
			J_select=0;
	}
	
	
	if((LPC_GPIO1->FIOPIN & (1<<26)) == 0){	
		
		J_down++;
		switch(J_down){
			case 1:
				if(mode==P_MODE){
					direction=DOWN;
					highlight_move(turn, Yellow);
				  select_move(turn, direction);
				}else{
						redo_wall();
						if(B.Y<6)
							B.Y++;
						draw_wall(L_WALL, 2, B.X, B.Y, 33, 33, B.vertical, Magenta);
				}
				break;
			default:
				break;
		}
	}
	else{
			J_down=0;
	}
	
	if((LPC_GPIO1->FIOPIN & (1<<27)) == 0){	
		
		J_left++;
		switch(J_left){
			case 1:
				if(mode==P_MODE){
					direction=LEFT;
					highlight_move(turn, Yellow);
				  select_move(turn, direction);
				}else{
					redo_wall();
					if(B.X>1)
						B.X--;
					draw_wall(L_WALL, 2, B.X, B.Y, 33, 33, B.vertical, Magenta);
				}
				break;
			default:
				break;
		}
	}
	else{
			J_left=0;
	}
	
	if((LPC_GPIO1->FIOPIN & (1<<28)) == 0){	
		
		J_right++;
		switch(J_right){
			case 1:
				if(mode==P_MODE){
					direction=RIGHT;
					highlight_move(turn, Yellow);
				  select_move(turn, direction);
				}else{
					redo_wall();
					if(B.X<6)
						B.X++;
					draw_wall(L_WALL, 2, B.X, B.Y, 33, 33, B.vertical, Magenta);
				}
				break;
			default:
				break;
		}
	}
	else{
			J_right=0;
	}
	
	if((LPC_GPIO1->FIOPIN & (1<<29)) == 0){	
		
		J_up++;
		switch(J_up){
			case 1:
				if(mode==P_MODE){
					direction=UP;
					highlight_move(turn, Yellow);
				  select_move(turn, direction);
			}else{
					redo_wall();
					if(B.Y>1)
						B.Y--;
				  draw_wall(L_WALL, 2, B.X, B.Y, 33, 33, B.vertical, Magenta);
			}
				break;
			default:
				break;
		}
	}
	else{
			J_up=0;
	}
}
	if(down_0!=0){  
		down_0 ++;  
	if((LPC_GPIO2->FIOPIN & (1<<10)) == 0){

		switch(down_0){
			case 2:
	
				LCD_Clear(Black);
	
				set_board();
				highlight_move(turn, Yellow);
				enable_timer(0);
	
				NVIC_EnableIRQ(EINT1_IRQn);
				
			
				joystick=1;
				break;
			default:
				break;
		}
	}
	else {	/* button released */
		down_0=0;			
		NVIC_EnableIRQ(EINT0_IRQn);							 /* enable Button interrupts			*/
		LPC_PINCON->PINSEL4    |= (1 << 20);     /* External interrupt 0 pin selection */
	}
	}
	
	if(down_1!=0){  
			down_1 ++;  
		if((LPC_GPIO2->FIOPIN & (1<<11)) == 0){

			switch(down_1){
				case 2:
					
	
	if(turn==P2_TURN)
		walls=P2.walls;
	else
		walls=P1.walls;
	
	if(mode==P_MODE){
		mode=W_MODE;
		if(walls!=0){
			NVIC_EnableIRQ(EINT2_IRQn);
			highlight_move(turn,Black);
			draw_wall(L_WALL, 2, B.X, B.Y, 33, 33, B.vertical, Magenta);
		}else{
			print_warning();
		}
	}
	else{
		GUI_Text(0, 235, (uint8_t *) "                              ", Black, Black);
		GUI_Text(0, 250, (uint8_t *) "                              ", Black, Black);
		joystick=1;
		NVIC_DisableIRQ(EINT2_IRQn);
		mode=P_MODE;
		draw_wall(L_WALL, 2, B.X, B.Y, 33, 33, B.vertical, Black);
		redo_wall();
		B.X=3;
		B.Y=3;
		highlight_move(turn,Yellow); 
	}
					break;
				default:				
					break;
		}
	}
	else {	/* button released */
		down_1=0;			
		NVIC_EnableIRQ(EINT1_IRQn);							 /* enable Button interrupts			*/
		LPC_PINCON->PINSEL4    |= (1 << 22);     /* External interrupt 1 pin selection */
	}
	
	}
	if(down_2!=0){  
			down_2 ++;  
		if((LPC_GPIO2->FIOPIN & (1<<12)) == 0){
			switch(down_2){
				case 2:
					rotate_wall();
					break;
				default:
					break;
		}
	}
	else {	/* button released */
		down_2=0;			
		NVIC_EnableIRQ(EINT2_IRQn); 							 /* enable Button interrupts			*/
		LPC_PINCON->PINSEL4    |= (1 << 24);     /* External interrupt 2 pin selection */
	}
	}
		
	reset_RIT();
  LPC_RIT->RICTRL |= 0x1;	/* clear interrupt flag */
	
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/
