/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_timer.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    timer.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "../functions.h"


extern uint16_t turn;
extern uint16_t mode;
extern Board B;
extern uint32_t moves[100];
extern Player P1;
extern Player P2;
extern int joystick;

volatile int count = TIME;



/******************************************************************************
** Function name:		Timer0_IRQHandler
**
** Descriptions:		Timer/Counter 0 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/

void TIMER0_IRQHandler (void)
{
	char stringa[5];
	
	if (count > 1){
		NVIC_DisableIRQ(EINT0_IRQn);
		count--;
		sprintf(stringa, "%d", count);
		strcat(stringa,"s");
		GUI_Text(112, FINE + 20, (uint8_t *) "   ", Black, Black);
		GUI_Text(112, FINE + 20, (uint8_t *) stringa, White, Black);	
	}else{
		
		if(mode==W_MODE){
			redo_wall();
			NVIC_DisableIRQ(EINT2_IRQn);
			mode=P_MODE;
		}
		
		highlight_move(turn, Black);
		
		if(turn==P2_TURN){
			add_move(turn,0,1,P2.Y,P2.X,moves);
			turn=P1_TURN;
		}else{
			add_move(turn,0,1,P1.Y,P1.X,moves);
			turn=P2_TURN;
		}
		
		highlight_move(turn, Yellow);
		B.X=3;
		B.Y=3;
		count=TIME;
		sprintf(stringa, "%d", count);
		strcat(stringa,"s");
		joystick=1;
		GUI_Text(112, FINE + 20, (uint8_t *) "   ", Black, Black);
		GUI_Text(112, FINE + 20, (uint8_t *) stringa, White, Black);
		
		if(P1.walls==0 || P2.walls==0){
			GUI_Text(0, 235, (uint8_t *) "                              ", Black, Black);
			GUI_Text(0, 250, (uint8_t *) "                              ", Black, Black);
		}
	}
  LPC_TIM0->IR = 1;			/* clear interrupt flag */
  return;
}


/******************************************************************************
** Function name:		Timer1_IRQHandler
**
** Descriptions:		Timer/Counter 1 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
void TIMER1_IRQHandler (void)
{
  LPC_TIM1->IR = 1;			/* clear interrupt flag */
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/
