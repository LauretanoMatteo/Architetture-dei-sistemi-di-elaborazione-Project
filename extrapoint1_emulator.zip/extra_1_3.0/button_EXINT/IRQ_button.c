#include "../functions.h"


extern int down_0;
extern int down_1;
extern int down_2;
extern Player P1;
extern Player P2;
extern uint16_t turn;
extern Board B;
extern uint16_t joystick;

extern uint16_t mode;


#ifdef SIMULATOR
extern uint8_t ScaleFlag; // <- ScaleFlag needs to visible in order for the emulator to find the symbol (can be placed also inside system_LPC17xx.h but since it is RO, it needs more work)
#endif


void EINT0_IRQHandler (void)	  	/* INT0														 */
{		
	down_0 = 1;
	
	NVIC_DisableIRQ(EINT0_IRQn);		
	LPC_PINCON->PINSEL4    &= ~(1 << 20); 

		
	
	LPC_SC->EXTINT &= (1 << 0);     /* clear pending interrupt         */
}


void EINT1_IRQHandler (void)	  	/* KEY1														 */
{
	down_1 = 1;
	NVIC_DisableIRQ(EINT1_IRQn);		/* disable Button interrupts			 */
	LPC_PINCON->PINSEL4    &= ~(1 << 22);     /* GPIO pin selection */
	
	
	
	LPC_SC->EXTINT &= (1 << 1);     /* clear pending interrupt         */
}

void EINT2_IRQHandler (void)	  	/* KEY2														 */
{
	down_2 = 1;
	NVIC_DisableIRQ(EINT2_IRQn);
	LPC_PINCON->PINSEL4    &= ~(1 << 24);     /* GPIO pin selection */
	
	LPC_SC->EXTINT &= (1 << 2);     /* clear pending interrupt         */    
}


